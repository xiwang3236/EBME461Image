% your_model.m: Define the aqueous humor production model
function y = your_model(x)

    % Extract parameters from vector x
    P_NKCC = x(1);
    P_AEs  = x(2);
    P_AEp  = x(3);
    P_NBCp = x(4);
    P_NBCs = x(5);
    P_NHE  = x(6);
    P_Ks   = x(7);
    P_Kp   = x(8);
    P_Clp  = x(9);
    P_tj   = x(10);

    % Fixed parameters from the baseline (Table 1)
    P_PUMP = 6e-6;

    % Initial guesses updated to match model_equations expected length (18 elements)
    init_guess = [17.8, 154.4, 45, 26.9, 7.46, -75.6, ... % cell concentrations/potential
                  151.8, 4.3, 126.9, 28.6, 7.49, -1.56, ... % PC concentrations/potential
                  1.0, 1.0, 1.0, 1.0, 1.0, 2.91e-11]; % additional species + flux

    options = optimoptions('fsolve','Display','off');

    % Solve the algebraic equations from the model
    try
        options = optimoptions('lsqnonlin','Display','off');
        lb = zeros(1,18);
ub = 200 * ones(1,18);
objective = @(vars) model_equations_safe(vars, [P_NKCC,P_AEs,P_AEp,P_NBCp,P_NBCs,P_NHE,P_Ks,P_Kp,P_Clp,P_tj,P_PUMP]);
options = optimoptions('particleswarm','Display','off','MaxIterations',50);
[sol, resnorm] = particleswarm(@(vars) norm(objective(vars)), 18, lb, ub, options);
[sol, resnorm] = particleswarm(@(vars) norm(objective(vars)), 18, lb, ub, options);
residual = objective(sol);
disp('Residuals from model_equations_safe:');
disp(residual);


        if any(isnan(sol)) || any(isinf(sol))
            error('Invalid solution');
        end
        % Extract results clearly
        Q        = sol(end);
        Conc_Na  = sol(7);
        Conc_K   = sol(8);
        Conc_Cl  = sol(9);
        Conc_HCO3= sol(10);
        % Output results
        y = [Q, Conc_Na, Conc_K, Conc_Cl, Conc_HCO3];
    catch
        % If fsolve fails, return NaNs and display input
        fprintf("fsolve failed for x = [");
        fprintf("%.3e ", x);
        fprintf("]\n");
        y = NaN(1,5);
    end
end
