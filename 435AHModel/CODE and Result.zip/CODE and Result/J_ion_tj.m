function J = J_ion_tj(P, C1, C2, V1, V2)
    J = P * (C1 - C2 + (V1 - V2));
end
