% main_FAST.m: Run this script to perform correlation-based sensitivity analysis
clear;
clc;

baseline_values = [1e-6,4e-6,0.4e-6,1e-6,6e-6,3.4e-6,5e-8,30e-8,6e-8,600e-8];
pmin = 0.5 .* baseline_values;
pmax = 1.5 .* baseline_values;

Parameter_names = {'P_{NKCC}','P_{AEs}','P_{AEp}','P_{NBCp}','P_{NBCs}',...
                   'P_{NHE}','P_{Ks}','P_{Kp}','P_{Clp}','P_{tj}'};

NR = length(baseline_values);
N = 1000; % number of samples

% Generate samples manually using Latin Hypercube Sampling
X_norm = lhsdesign(N, NR);
X = zeros(N, NR);
for j = 1:NR
    X(:, j) = pmin(j) + X_norm(:, j) .* (pmax(j) - pmin(j));
end

% Evaluate the model
num_outputs = 5; % [Q, Conc_Na, Conc_K, Conc_Cl, Conc_HCO3]
Y = NaN(N, num_outputs);
for i = 1:N
    Y(i, :) = your_model(X(i, :));
end

% Report how many calls succeeded
fprintf("Valid outputs: %d of %d\n", sum(all(~isnan(Y), 2)), N);

% Remove any NaN rows
valid_rows = all(~isnan(Y), 2);
X_valid = X(valid_rows, :);
Y_valid = Y(valid_rows, :);

% Correlation-based sensitivity (Pearson correlation coefficients)
Si = zeros(num_outputs, NR);
for i = 1:num_outputs
    for j = 1:NR
        xj = X_valid(:, j);
        yj = Y_valid(:, i);
        if all(isfinite(xj)) && all(isfinite(yj))
            R = corrcoef(xj, yj);
            Si(i, j) = abs(R(1, 2));
        else
            Si(i, j) = NaN;
        end
    end
end

% Visualization similar to Figure 3
figure;
bar(Si(1,:));
set(gca,'xticklabel',Parameter_names,'XTickLabelRotation',45);
ylabel('|Correlation|');
title('AH Production Rate (Q) Sensitivity');

figure;
bar(Si(2:5,:)');
set(gca,'xticklabel',Parameter_names,'XTickLabelRotation',45);
legend({'Na^+', 'K^+', 'Cl^-', 'HCO_3^-'}, 'Location', 'northeastoutside');
ylabel('|Correlation|');
title('PC Ion Concentration Sensitivity (Figure 3B Style)');
