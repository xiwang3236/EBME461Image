function J = J_K_flux(P, C1, C2, phi)
    safe_exp = @(x) exp(min(max(x, -100), 100));
    exp_neg = safe_exp(-phi);
    denom = max(1 - exp_neg, 1e-12);
    J = P * (phi * (C1 - C2 * exp_neg)) / denom;
end
