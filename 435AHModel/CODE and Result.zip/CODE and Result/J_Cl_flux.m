function J = J_Cl_flux(P, C1, C2, phi)
    safe_exp = @(x) exp(min(max(x, -100), 100));
    exp_pos = safe_exp(phi);
    denom = max(1 - exp_pos, 1e-12);
    J = -P * (phi * (C1 - C2 * exp_pos)) / denom;
end
