function F = model_equations_safe(vars, params)
    % Unpack variables (shortened version with CO2 <-> H+ linkage)
    Cc_Na = vars(1); Cc_K = vars(2); Cc_Cl = vars(3); Cc_HCO3 = vars(4); Cc_H = vars(5); Vc = vars(6);
    Cp_Na = vars(7); Cp_K = vars(8); Cp_Cl = vars(9); Cp_HCO3 = vars(10); Cp_H = vars(11); Vp = vars(12);
    Cc_CO2 = vars(13); Cp_CO2 = vars(14);

    % Unpack parameters
    P_NKCC = params(1); P_AEs = params(2); P_AEp = params(3);
    P_NBCp = params(4); P_NBCs = params(5); P_NHE = params(6);
    P_Ks = params(7); P_Kp = params(8); P_Clp = params(9); P_tj = params(10); P_PUMP = params(11);

    % Constants
    R = 8.314; T = 310; Fd = 96485; zX = -1.5; Kd = 5.3;
    Cs_Na = 150; Cs_K = 5; Cs_Cl = 130; Cs_HCO3 = 25; Cs_H = 10^(-7.42)*1e3; Vs = 0;

    % Safe log
    slog = @(x) log(max(x, 1e-12));
    safe_exp = @(x) exp(min(max(x, -100), 100));

    % Potentials
    phi_sc = Fd*(Vs - Vc)/(R*T);
    phi_pc = Fd*(Vp - Vc)/(R*T);

    % Fluxes
    J_NKCC = P_NKCC * slog((Cc_K*Cc_Na*(Cc_Cl)^2)/(Cs_K*Cs_Na*(Cs_Cl)^2));
    J_NHE = P_NHE * slog((Cs_H*Cc_Na)/(Cc_H*Cs_Na));
    J_NBCs = P_NBCs * (slog((Cc_Na*(Cc_HCO3)^2)/(Cs_Na*(Cs_HCO3)^2)) - phi_sc);
    J_NBCp = P_NBCp * (slog((Cc_Na*(Cc_HCO3)^2)/(Cp_Na*(Cp_HCO3)^2)) - phi_pc);
    J_AEs = P_AEs * slog((Cs_Cl*Cc_HCO3)/(Cc_Cl*Cs_HCO3));
    J_AEp = P_AEp * slog((Cp_Cl*Cc_HCO3)/(Cc_Cl*Cp_HCO3));

    KNa = 0.2*(1+Cc_K/8.33);
    KK = 0.1*(1+Cp_Na/18.5);
    J_PUMP = P_PUMP*(Cc_Na/(KNa+Cc_Na))^3*(Cp_K/(KK+Cp_K))^2;

    % Equations (simplified, H2CO3 removed)
    F(1) = 3*J_PUMP + J_NKCC + J_NBCs + J_NBCp - J_NHE;
    F(2) = J_K_flux(P_Ks,Cs_K,Cc_K,phi_sc) + J_NKCC - 2*J_PUMP + J_K_flux(P_Kp,Cp_K,Cc_K,phi_pc);
    F(3) = 2*J_NKCC - J_AEs - J_AEp + J_Cl_flux(P_Clp,Cp_Cl,Cc_Cl,phi_pc);
    F(4) = J_AEs + J_AEp + 2*J_NBCp + 2*J_NBCs - J_NHE;
    F(5) = Cc_CO2 - Kd*Cc_HCO3*Cc_H;  % H+ + HCO3- <-> CO2 (cell)
    F(6) = Cc_Na + Cc_K - Cc_Cl - Cc_HCO3 - Cc_H;  % electroneutrality

    F(7) = 3*J_PUMP + J_NBCp + J_ion_tj(P_tj,Cs_Na,Cp_Na,Vs,Vp);
    F(8) = J_K_flux(P_Kp,Cc_K,Cp_K,-phi_pc) - 2*J_PUMP + J_ion_tj(P_tj,Cs_K,Cp_K,Vs,Vp);
    F(9) = J_Cl_flux(P_Clp,Cc_Cl,Cp_Cl,-phi_pc) - J_AEp + J_ion_tj(P_tj,Cs_Cl,Cp_Cl,Vs,Vp);
    F(10)= J_AEp + 2*J_NBCp + J_ion_tj(P_tj,Cs_HCO3,Cp_HCO3,Vs,Vp);
    F(11)= Cp_CO2 - Kd*Cp_HCO3*Cp_H;  % H+ + HCO3- <-> CO2 (PC)
    F(12)= Cp_Na + Cp_K - Cp_Cl - Cp_HCO3 - Cp_H;

    sigmaRT = R*T;
    osm_diff = (Cp_Na+Cp_K+Cp_Cl+Cp_HCO3)-(Cs_Na+Cs_K+Cs_Cl+Cs_HCO3);
    F(13)= - sigmaRT*osm_diff;

    % Return reduced system (13 equations, no CX or Q)
    F(14) = Cp_Na + Cp_K + Cp_Cl + Cp_HCO3 + Cp_H + Cp_CO2 - (Cc_Na + Cc_K + Cc_Cl + Cc_HCO3 + Cc_H + Cc_CO2); % overall mass/charge or osmotic continuity
F(15) = Cc_Na + Cc_K + Cp_Na + Cp_K - (Cc_Cl + Cp_Cl + Cc_HCO3 + Cp_HCO3); % total cation-anion balance

F = F(1:15);
end
